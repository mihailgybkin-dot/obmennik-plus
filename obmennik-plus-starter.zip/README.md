
# Обменник + (MVP для Vercel)

- Next.js (app router) + Tailwind
- /api/rates парсит первую строку BestChange и даёт курс (MVP эвристика)
- Простая magic-link аутентификация без БД (JWT + email через Resend или dev‑ссылка)
- Личный кабинет (демо): хранит историю и email в localStorage (для продакшена добавьте БД)

## Быстрый старт
1) `npm i`
2) `npm run dev`
3) Откройте http://localhost:3000

## Переменные окружения
- `SITE_URL` — ваш домен (например, https://obmennik-plus.vercel.app)
- `RESEND_API_KEY` — (опционально) для отправки email
- `JWT_SECRET` — секрет для подписи токенов (задайте длинную случайную строку)

Если `RESEND_API_KEY` не задан, API вернёт dev‑ссылку/токен в JSON.
